# Projeto-Poo
Projeto sobre Reconhecimento de Placas Veiculares, destinado para disciplina de Programação Orientada a Objeto.
